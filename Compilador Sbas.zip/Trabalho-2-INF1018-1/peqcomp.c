/* Eduardo Infante de Castro Thompson 2310826 Turma */
/* Bernardo Borges Vieira 2211838 Turma */
#include "peqcomp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>
#include <malloc.h>

__asm__(".section .note.GNU-stack,\"\",@progbits");

#define MAX_LINHAS 1000
#define MIN_CODE_SIZE 4096

// Função para debug que imprime o código gerado
void debug_print_code(unsigned char *code, int size) {
    printf("Código gerado (%d bytes):\n", size);
    for (int i = 0; i < size; i++) {
        printf("%02x ", code[i]);
        if ((i+1) % 8 == 0) printf("\n");
    }
    printf("\n");
}

funcp peqcomp(FILE *f, unsigned char codigo[]) {
    printf("Iniciando compilação...\n");

    long page_size = sysconf(_SC_PAGESIZE);
    if (page_size == -1) {
        perror("sysconf failed");
        exit(1);
    }
    printf("Tamanho da página: %ld\n", page_size);

    int needs_free = 0;
    unsigned char *exec_buffer = codigo;

    if (((uintptr_t)codigo % page_size) != 0) {
        printf("Alocando buffer alinhado...\n");
        exec_buffer = memalign(page_size, MIN_CODE_SIZE);
        if (!exec_buffer) {
            perror("memalign failed");
            exit(1);
        }
        needs_free = 1;
    }

    int pos = 0;
    int line_numbers[MAX_LINHAS];
    long offsets[MAX_LINHAS];
    int num_lines = 0;

    // Primeira passagem - construir tabela de linhas
    printf("Primeira passagem...\n");
    rewind(f);
    char linha[256];
    int current_line = 0;

    while (fgets(linha, sizeof(linha), f) != NULL) {
        current_line++;
        if (linha[0] == '\n' || linha[0] == '\0') continue;

        printf("Linha %d: %s", current_line, linha);

        line_numbers[num_lines] = current_line;
        offsets[num_lines] = pos;
        num_lines++;

        if (strstr(linha, "iflez") == linha) {
            pos += 11;
            printf("  iflez -> +11 bytes (total: %d)\n", pos);
        }
        else if (strstr(linha, "ret $") == linha) {
            pos += 7;
            printf("  ret $ -> +7 bytes (total: %d)\n", pos);
        }
        else if (strstr(linha, "ret v") == linha) {
            pos += 5;
            printf("  ret v -> +5 bytes (total: %d)\n", pos);
        }
        else if (strstr(linha, "=") != NULL) {
            pos += 10;
            printf("  atribuição -> +10 bytes (total: %d)\n", pos);
        }
        else if (strstr(linha, ": p") != NULL) {
            pos += 4;
            printf("  param -> +4 bytes (total: %d)\n", pos);
        }
        else if (strstr(linha, ": $") != NULL) {
            pos += 8;
            printf("  const -> +8 bytes (total: %d)\n", pos);
        }
    }

    // Segunda passagem - gerar código
    printf("\nSegunda passagem...\n");
    rewind(f);
    current_line = 0;
    pos = 0;

    // Prólogo da função
    printf("[%03d] Prólogo da função\n", pos);
    exec_buffer[pos++] = 0x55;                   // push rbp
    exec_buffer[pos++] = 0x48; exec_buffer[pos++] = 0x89; exec_buffer[pos++] = 0xe5; // mov rbp, rsp
    exec_buffer[pos++] = 0x48; exec_buffer[pos++] = 0x83; exec_buffer[pos++] = 0xec; exec_buffer[pos++] = 0x20; // sub rsp, 32

    while (fgets(linha, sizeof(linha), f) != NULL) {
        current_line++;
        if (linha[0] == '\n' || linha[0] == '\0') continue;

        printf("Compilando linha %d: %s", current_line, linha);

        int val, idx, target, dst, src, cst, param;
        char op;

        if (sscanf(linha, "v%d : $%d", &idx, &val) == 2) {
            printf("  [%03d] v%d = %d\n", pos, idx, val);
            exec_buffer[pos++] = 0xc7;           // mov [rbp-4*idx], imm32
            exec_buffer[pos++] = 0x45;
            exec_buffer[pos++] = (unsigned char)(-4 * idx);
            memcpy(&exec_buffer[pos], &val, 4);
            pos += 4;
        }
        else if (sscanf(linha, "v%d : p%d", &idx, &param) == 2) {
            printf("  [%03d] v%d = param%d\n", pos, idx, param);
            exec_buffer[pos++] = 0x89;           // mov [rbp-4*idx], param_reg
            exec_buffer[pos++] = (param == 1) ? 0x7d : (param == 2) ? 0x75 : 0x55;
            exec_buffer[pos++] = (unsigned char)(-4 * idx);
        }
        else if (sscanf(linha, "ret $%d", &val) == 1) {
            printf("  [%03d] ret %d\n", pos, val);
            exec_buffer[pos++] = 0xb8;           // mov eax, imm32
            memcpy(&exec_buffer[pos], &val, 4);
            pos += 4;
            exec_buffer[pos++] = 0xc9;           // leave
            exec_buffer[pos++] = 0xc3;           // ret
        }
        else if (sscanf(linha, "ret v%d", &idx) == 1) {
            printf("  [%03d] ret v%d\n", pos, idx);
            exec_buffer[pos++] = 0x8b;           // mov eax, [rbp-4*idx]
            exec_buffer[pos++] = 0x45;
            exec_buffer[pos++] = (unsigned char)(-4 * idx);
            exec_buffer[pos++] = 0xc9;           // leave
            exec_buffer[pos++] = 0xc3;           // ret
        }
        else if (sscanf(linha, "iflez v%d %d", &idx, &target) == 2) {
            printf("  [%03d] iflez v%d -> linha %d\n", pos, idx, target);

            long target_offset = -1;
            for (int i = 0; i < num_lines; i++) {
                if (line_numbers[i] == target) {
                    target_offset = offsets[i];
                    break;
                }
            }

            if (target_offset == -1) {
                fprintf(stderr, "Erro: destino de salto inválido na linha %d\n", current_line);
                if (needs_free) free(exec_buffer);
                exit(1);
            }

            // cmp [rbp-4*idx], 0
            exec_buffer[pos++] = 0x83;
            exec_buffer[pos++] = 0x7d;
            exec_buffer[pos++] = (unsigned char)(-4 * idx);
            exec_buffer[pos++] = 0x00;

            // jle target (rel32)
            exec_buffer[pos++] = 0x0f;
            exec_buffer[pos++] = 0x8e;
            int rel_offset = (int)(target_offset - (pos + 4));
            printf("    Salto para %ld (offset relativo %d)\n", target_offset, rel_offset);
            memcpy(&exec_buffer[pos], &rel_offset, 4);
            pos += 4;
        }
        else if (sscanf(linha, "v%d = v%d %c $%d", &dst, &src, &op, &cst) == 4) {
            printf("  [%03d] v%d = v%d %c %d\n", pos, dst, src, op, cst);
            // mov eax, [rbp-4*src]
            exec_buffer[pos++] = 0x8b;
            exec_buffer[pos++] = 0x45;
            exec_buffer[pos++] = (unsigned char)(-4 * src);

            // Realizar operação
            switch(op) {
                case '+': 
                    exec_buffer[pos++] = 0x05;  // add eax, imm32
                    break;
                case '-': 
                    exec_buffer[pos++] = 0x2d;  // sub eax, imm32
                    break;
                case '*': 
                    exec_buffer[pos++] = 0x69;  // imul eax, eax, imm32
                    exec_buffer[pos++] = 0xc0;
                    break;
                default:
                    fprintf(stderr, "Erro: operador '%c' não suportado\n", op);
                    if (needs_free) free(exec_buffer);
                    exit(1);
            }
            memcpy(&exec_buffer[pos], &cst, 4);
            pos += 4;

            // mov [rbp-4*dst], eax
            exec_buffer[pos++] = 0x89;
            exec_buffer[pos++] = 0x45;
            exec_buffer[pos++] = (unsigned char)(-4 * dst);
        }
    }

    // Garantir que há um retorno no final
    if (pos == 0 || exec_buffer[pos-1] != 0xc3) {
        printf("  [%03d] Adicionando retorno padrão\n", pos);
        exec_buffer[pos++] = 0xb8;  // mov eax, 0
        exec_buffer[pos++] = 0x00;
        exec_buffer[pos++] = 0x00;
        exec_buffer[pos++] = 0x00;
        exec_buffer[pos++] = 0x00;
        exec_buffer[pos++] = 0xc9;  // leave
        exec_buffer[pos++] = 0xc3;  // ret
    }

    // Configurar permissões de memória
    size_t code_size = ((pos + page_size - 1) / page_size) * page_size;
    printf("\nConfigurando permissões para %zd bytes de código...\n", code_size);
    if (mprotect(exec_buffer, code_size, PROT_READ | PROT_EXEC) == -1) {
        perror("mprotect falhou");
        if (needs_free) free(exec_buffer);
        exit(1);
    }

    if (needs_free) {
        printf("Copiando código para buffer original...\n");
        memcpy(codigo, exec_buffer, pos);
        free(exec_buffer);
    }

    debug_print_code(codigo, pos);
    printf("Compilação concluída com sucesso!\n");

    return (funcp)codigo;
}