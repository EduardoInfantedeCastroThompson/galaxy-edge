#include "peqcomp.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  printf("Começando\n");
  FILE *f = fopen("teste6.txt", "r");
  if (f == NULL) {
    perror("Erro ao abrir programa.txt");
    return 1;
  }

  unsigned char codigo[100];
  funcp func = peqcomp(f, codigo);
  fclose(f);

  int resultado = func(6);
  printf("Resultado: %d\n", resultado);

  return 0;
}
